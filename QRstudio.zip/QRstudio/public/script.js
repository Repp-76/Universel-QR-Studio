/* ---------------------------------------------------------
   Universal QR Studio — client logic
   QR matrix comes from qrcode-generator (window.qrcode).
   Everything visual is drawn ourselves on canvas so the 21
   styles can genuinely differ in shape, not just color.
--------------------------------------------------------- */

const STYLES = [
  { id: 'classic',     name: 'Classic',       moduleShape: 'square',  scale: 1.0,  eyeFrame: 'square',  eyeBall: 'square',  fg: '#000000', bg: '#ffffff', eye: '#000000' },
  { id: 'rounded',     name: 'Rounded',       moduleShape: 'rounded', scale: 0.88, eyeFrame: 'rounded', eyeBall: 'rounded', fg: '#111111', bg: '#ffffff', eye: '#111111' },
  { id: 'minimal',     name: 'Minimal',       moduleShape: 'dot',     scale: 0.5,  eyeFrame: 'circle',  eyeBall: 'circle',  fg: '#1f1f1f', bg: '#ffffff', eye: '#1f1f1f' },
  { id: 'softdot',     name: 'Soft Dot',      moduleShape: 'dot',     scale: 0.82, eyeFrame: 'rounded', eyeBall: 'rounded', fg: '#374151', bg: '#f3f4f6', eye: '#374151' },
  { id: 'modernsq',    name: 'Modern Square', moduleShape: 'square',  scale: 0.78, eyeFrame: 'square',  eyeBall: 'rounded', fg: '#0f172a', bg: '#ffffff', eye: '#0f172a' },
  { id: 'pixel',       name: 'Pixel',         moduleShape: 'square',  scale: 0.6,  eyeFrame: 'square',  eyeBall: 'square',  fg: '#000000', bg: '#ffffff', eye: '#000000' },
  { id: 'circlematrix',name: 'Circle Matrix', moduleShape: 'dot',     scale: 1.0,  eyeFrame: 'circle',  eyeBall: 'circle',  fg: '#111111', bg: '#ffffff', eye: '#111111' },
  { id: 'diamond',     name: 'Diamond',       moduleShape: 'diamond', scale: 0.86, eyeFrame: 'square',  eyeBall: 'diamond', fg: '#111111', bg: '#ffffff', eye: '#111111' },
  { id: 'elegant',     name: 'Elegant',       moduleShape: 'rounded', scale: 0.7,  eyeFrame: 'circle',  eyeBall: 'diamond', fg: '#1e293b', bg: '#f8fafc', eye: '#334155' },
  { id: 'luxury',      name: 'Luxury',        moduleShape: 'square',  scale: 0.85, eyeFrame: 'square',  eyeBall: 'square',  fg: '#d4af37', bg: '#0b0b0c', eye: '#d4af37', gradient: ['#caa14d', '#f4e2a1'] },
  { id: 'glass',       name: 'Glass',         moduleShape: 'rounded', scale: 0.76, eyeFrame: 'rounded', eyeBall: 'circle',  fg: '#60a5fa', bg: '#eef2ff', eye: '#6366f1', gradient: ['#60a5fa', '#a78bfa'], alpha: 0.85 },
  { id: 'neon',        name: 'Neon',          moduleShape: 'dot',     scale: 0.8,  eyeFrame: 'circle',  eyeBall: 'circle',  fg: '#39ff14', bg: '#070707', eye: '#39ff14', glow: true },
  { id: 'gradient',    name: 'Gradient',      moduleShape: 'square',  scale: 0.85, eyeFrame: 'rounded', eyeBall: 'rounded', fg: '#8b5cf6', bg: '#ffffff', eye: '#8b5cf6', gradient: ['#8b5cf6', '#ec4899'] },
  { id: 'cyber',       name: 'Cyber',         moduleShape: 'square',  scale: 0.8,  eyeFrame: 'square',  eyeBall: 'square',  fg: '#00e5ff', bg: '#05070a', eye: '#00e5ff', glow: true, scanlines: true },
  { id: 'tech',        name: 'Tech',          moduleShape: 'rounded', scale: 0.78, eyeFrame: 'square',  eyeBall: 'square',  fg: '#2563eb', bg: '#f8fafc', eye: '#0ea5e9', gradient: ['#2563eb', '#0ea5e9'], outlineEyes: true },
  { id: 'bold',        name: 'Bold',          moduleShape: 'square',  scale: 1.08, eyeFrame: 'square',  eyeBall: 'square',  fg: '#000000', bg: '#ffffff', eye: '#000000' },
  { id: 'mono',        name: 'Mono',          moduleShape: 'square',  scale: 1.0,  eyeFrame: 'square',  eyeBall: 'square',  fg: '#000000', bg: '#ffffff', eye: '#000000' },
  { id: 'outline',     name: 'Outline',       moduleShape: 'square',  scale: 0.8,  eyeFrame: 'square',  eyeBall: 'square',  fg: '#111111', bg: '#ffffff', eye: '#111111', outlineModules: true },
  { id: 'premium',     name: 'Premium',       moduleShape: 'rounded', scale: 0.84, eyeFrame: 'square',  eyeBall: 'square',  fg: '#0a0a0a', bg: '#fbfbf9', eye: '#b08d57', border: true },
  { id: 'futuristic',  name: 'Futuristic',    moduleShape: 'diamond', scale: 0.82, eyeFrame: 'circle',  eyeBall: 'square',  fg: '#22d3ee', bg: '#050814', eye: '#6366f1', gradient: ['#22d3ee', '#6366f1'], glow: true },
  { id: 'signature',   name: 'Signature',     moduleShape: 'rounded', scale: 0.85, eyeFrame: 'rounded', eyeBall: 'rounded', fg: '#111827', bg: '#ffffff', eye: '#111827', frame: true, frameText: 'SCAN ME' },
];

let state = {
  styleId: 'classic',
  fg: '#000000', bg: '#ffffff', eye: '#000000',
  useGradient: false, gradientEnd: '#7c3aed',
  moduleShape: 'square', eyeFrame: 'square', eyeBall: 'square',
  margin: 4, ec: 'M',
  logoImg: null, logoSize: 20,
  frameOn: false, frameText: 'SCAN ME',
};

let qrText = null;

/* ---------------- geometry helpers ---------------- */

function roundRectPath(ctx, x, y, w, h, r) {
  r = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

function shapePath(ctx, kind, x, y, w, h) {
  if (kind === 'circle' || kind === 'dot') {
    ctx.beginPath();
    ctx.ellipse(x + w / 2, y + h / 2, w / 2, h / 2, 0, 0, Math.PI * 2);
  } else if (kind === 'diamond') {
    ctx.beginPath();
    ctx.moveTo(x + w / 2, y);
    ctx.lineTo(x + w, y + h / 2);
    ctx.lineTo(x + w / 2, y + h);
    ctx.lineTo(x, y + h / 2);
    ctx.closePath();
  } else if (kind === 'rounded') {
    roundRectPath(ctx, x, y, w, h, Math.min(w, h) * 0.32);
  } else {
    ctx.beginPath();
    ctx.rect(x, y, w, h);
  }
}

function inFinderZone(row, col, n) {
  return (row < 7 && col < 7) || (row < 7 && col >= n - 7) || (row >= n - 7 && col < 7);
}

/* ---------------- matrix ---------------- */

function buildMatrix(text, ecLevel) {
  const qr = qrcode(0, ecLevel);
  qr.addData(text);
  qr.make();
  const count = qr.getModuleCount();
  const dark = (r, c) => qr.isDark(r, c);
  return { count, dark };
}

/* ---------------- main render ---------------- */

function activeStyle() {
  return STYLES.find(s => s.id === state.styleId) || STYLES[0];
}

function renderQR(canvas, text, cfg) {
  const style = STYLES.find(s => s.id === cfg.styleId) || STYLES[0];
  const { count, dark } = buildMatrix(text, cfg.ec);
  const n = count + cfg.margin * 2;

  const withFrame = cfg.frameOn || style.frame;
  const qrPx = canvas.__baseSize || canvas.width;
  const framePx = withFrame ? Math.round(qrPx * 0.16) : 0;

  canvas.width = qrPx;
  canvas.height = qrPx + framePx;
  const ctx = canvas.getContext('2d');
  const cell = qrPx / n;

  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = cfg.bg;
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  let fillStyle = cfg.fg;
  if (cfg.useGradient) {
    const grad = ctx.createLinearGradient(0, 0, qrPx, qrPx);
    grad.addColorStop(0, cfg.fg);
    grad.addColorStop(1, cfg.gradientEnd);
    fillStyle = grad;
  }

  if (style.glow) {
    ctx.shadowColor = cfg.eye;
    ctx.shadowBlur = cell * 1.4;
  }

  // body modules
  for (let r = 0; r < count; r++) {
    for (let c = 0; c < count; c++) {
      if (!dark(r, c) || inFinderZone(r, c, count)) continue;
      const x = (c + cfg.margin) * cell;
      const y = (r + cfg.margin) * cell;
      const s = cell * cfg.scale;
      const off = (cell - s) / 2;
      shapePath(ctx, cfg.moduleShape, x + off, y + off, s, s);
      if (style.outlineModules) {
        ctx.strokeStyle = fillStyle;
        ctx.lineWidth = Math.max(1, cell * 0.14);
        ctx.stroke();
      } else {
        ctx.fillStyle = fillStyle;
        ctx.fill();
      }
    }
  }

  // three finder eyes
  const corners = [
    [cfg.margin, cfg.margin],
    [cfg.margin, cfg.margin + count - 7],
    [cfg.margin + count - 7, cfg.margin],
  ];
  for (const [r0, c0] of corners) {
    const x = c0 * cell, y = r0 * cell, box = cell * 7;
    shapePath(ctx, cfg.eyeFrame, x, y, box, box);
    if (style.outlineEyes) {
      ctx.lineWidth = Math.max(1.5, cell * 0.3);
      ctx.strokeStyle = cfg.eye;
      ctx.stroke();
    } else {
      ctx.fillStyle = cfg.eye;
      ctx.fill();
    }
    shapePath(ctx, cfg.eyeFrame, x + cell, y + cell, box - cell * 2, box - cell * 2);
    ctx.fillStyle = cfg.bg;
    ctx.fill();
    shapePath(ctx, cfg.eyeBall, x + cell * 2, y + cell * 2, box - cell * 4, box - cell * 4);
    ctx.fillStyle = cfg.eye;
    ctx.fill();
  }

  ctx.shadowBlur = 0;

  if (style.scanlines) {
    ctx.globalAlpha = 0.06;
    ctx.fillStyle = '#ffffff';
    for (let y = 0; y < qrPx; y += 3) ctx.fillRect(0, y, qrPx, 1);
    ctx.globalAlpha = 1;
  }

  if (style.border) {
    ctx.strokeStyle = cfg.eye;
    ctx.lineWidth = Math.max(2, qrPx * 0.006);
    roundRectPath(ctx, cell * cfg.margin * 0.35, cell * cfg.margin * 0.35, qrPx - cell * cfg.margin * 0.7, qrPx - cell * cfg.margin * 0.7, 8);
    ctx.stroke();
  }

  if (cfg.logoImg) {
    const logoBox = qrPx * (cfg.logoSize / 100);
    const cx = qrPx / 2, cy = qrPx / 2;
    const pad = logoBox * 0.18;
    ctx.fillStyle = cfg.bg;
    roundRectPath(ctx, cx - logoBox / 2 - pad / 2, cy - logoBox / 2 - pad / 2, logoBox + pad, logoBox + pad, 10);
    ctx.fill();
    ctx.drawImage(cfg.logoImg, cx - logoBox / 2, cy - logoBox / 2, logoBox, logoBox);
  }

  if (withFrame) {
    ctx.fillStyle = cfg.eye;
    ctx.fillRect(0, qrPx, qrPx, framePx);
    ctx.fillStyle = cfg.bg;
    ctx.font = `600 ${Math.round(framePx * 0.34)}px ${getComputedStyle(document.body).fontFamily}`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText((cfg.frameText || 'SCAN ME').toUpperCase(), qrPx / 2, qrPx + framePx / 2);
  }
}

function currentConfig() {
  return { styleId: state.styleId, fg: state.fg, bg: state.bg, eye: state.eye,
    useGradient: state.useGradient, gradientEnd: state.gradientEnd,
    moduleShape: state.moduleShape, eyeFrame: state.eyeFrame, eyeBall: state.eyeBall,
    margin: state.margin, ec: state.ec, logoImg: state.logoImg, logoSize: state.logoSize,
    frameOn: state.frameOn, frameText: state.frameText };
}

function redraw() {
  if (!qrText) return;
  const canvas = document.getElementById('qrCanvas');
  canvas.__baseSize = 600;
  renderQR(canvas, qrText, currentConfig());
}

/* ---------------- style grid ---------------- */

function buildStyleGrid() {
  const grid = document.getElementById('styleGrid');
  grid.innerHTML = '';
  STYLES.forEach(style => {
    const cell = document.createElement('div');
    cell.className = 'style-swatch' + (style.id === state.styleId ? ' active' : '');
    cell.dataset.id = style.id;
    const canvas = document.createElement('canvas');
    canvas.__baseSize = 88;
    grid.appendChild(cell);
    cell.appendChild(canvas);
    const label = document.createElement('span');
    label.textContent = style.name;
    cell.appendChild(label);

    const cfg = {
      styleId: style.id, fg: style.fg, bg: style.bg, eye: style.eye,
      useGradient: !!style.gradient, gradientEnd: style.gradient ? style.gradient[1] : '#000000',
      moduleShape: style.moduleShape, eyeFrame: style.eyeFrame, eyeBall: style.eyeBall,
      margin: 2, ec: 'M', logoImg: null, logoSize: 20, frameOn: false, frameText: 'SCAN ME',
    };
    if (style.gradient) cfg.fg = style.gradient[0];
    renderQR(canvas, 'https://repp76.dev', cfg);

    cell.addEventListener('click', () => applyStyle(style.id));
  });
}

function applyStyle(id) {
  const style = STYLES.find(s => s.id === id);
  if (!style) return;
  state.styleId = id;
  state.moduleShape = style.moduleShape;
  state.eyeFrame = style.eyeFrame;
  state.eyeBall = style.eyeBall;
  state.fg = style.gradient ? style.gradient[0] : style.fg;
  state.bg = style.bg;
  state.eye = style.eye;
  state.useGradient = !!style.gradient;
  state.gradientEnd = style.gradient ? style.gradient[1] : '#7c3aed';
  state.frameOn = !!style.frame;
  if (style.frameText) state.frameText = style.frameText;
  syncControlsFromState();
  document.querySelectorAll('.style-swatch').forEach(el => el.classList.toggle('active', el.dataset.id === id));
  redraw();
}

function syncControlsFromState() {
  document.getElementById('fgColor').value = state.fg;
  document.getElementById('bgColor').value = state.bg;
  document.getElementById('eyeColor').value = state.eye;
  document.getElementById('gradientToggle').checked = state.useGradient;
  document.getElementById('gradientEnd').value = state.gradientEnd;
  document.getElementById('gradientEndRow').style.display = state.useGradient ? 'flex' : 'none';
  document.getElementById('moduleShape').value = state.moduleShape;
  document.getElementById('eyeFrameShape').value = state.eyeFrame;
  document.getElementById('eyeBallShape').value = state.eyeBall;
  document.getElementById('marginRange').value = state.margin;
  document.getElementById('errorCorrection').value = state.ec;
  document.getElementById('frameToggle').checked = state.frameOn;
  document.getElementById('frameTextRow').style.display = state.frameOn ? 'flex' : 'none';
  document.getElementById('frameText').value = state.frameText;
}

/* ---------------- controls wiring ---------------- */

function wireControls() {
  document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
      tab.classList.add('active');
      document.getElementById('tab-' + tab.dataset.tab).classList.add('active');
    });
  });

  document.getElementById('fgColor').addEventListener('input', e => { state.fg = e.target.value; redraw(); });
  document.getElementById('bgColor').addEventListener('input', e => { state.bg = e.target.value; redraw(); });
  document.getElementById('eyeColor').addEventListener('input', e => { state.eye = e.target.value; redraw(); });
  document.getElementById('gradientToggle').addEventListener('change', e => {
    state.useGradient = e.target.checked;
    document.getElementById('gradientEndRow').style.display = state.useGradient ? 'flex' : 'none';
    redraw();
  });
  document.getElementById('gradientEnd').addEventListener('input', e => { state.gradientEnd = e.target.value; redraw(); });

  document.getElementById('moduleShape').addEventListener('change', e => { state.moduleShape = e.target.value; redraw(); });
  document.getElementById('eyeFrameShape').addEventListener('change', e => { state.eyeFrame = e.target.value; redraw(); });
  document.getElementById('eyeBallShape').addEventListener('change', e => { state.eyeBall = e.target.value; redraw(); });
  document.getElementById('marginRange').addEventListener('input', e => { state.margin = Number(e.target.value); redraw(); });
  document.getElementById('errorCorrection').addEventListener('change', e => { state.ec = e.target.value; redraw(); });

  document.getElementById('logoInput').addEventListener('change', e => {
    const file = e.target.files[0];
    if (!file) return;
    const img = new Image();
    img.onload = () => { state.logoImg = img; redraw(); };
    img.src = URL.createObjectURL(file);
  });
  document.getElementById('logoSize').addEventListener('input', e => { state.logoSize = Number(e.target.value); redraw(); });

  document.getElementById('frameToggle').addEventListener('change', e => {
    state.frameOn = e.target.checked;
    document.getElementById('frameTextRow').style.display = state.frameOn ? 'flex' : 'none';
    redraw();
  });
  document.getElementById('frameText').addEventListener('input', e => { state.frameText = e.target.value; redraw(); });

  document.querySelectorAll('[data-dl]').forEach(btn => {
    btn.addEventListener('click', () => downloadQR(btn.dataset.dl));
  });
}

/* ---------------- export ---------------- */

function downloadQR(format) {
  const canvas = document.getElementById('qrCanvas');
  if (format === 'svg') {
    downloadSVG();
    return;
  }
  const mime = format === 'jpg' ? 'image/jpeg' : 'image/png';
  const url = canvas.toDataURL(mime, 0.95);
  const a = document.createElement('a');
  a.href = url;
  a.download = `qr-${state.styleId}.${format}`;
  a.click();
}

function downloadSVG() {
  const cfg = currentConfig();
  const { count, dark } = buildMatrix(qrText, cfg.ec);
  const n = count + cfg.margin * 2;
  const size = 600;
  const cell = size / n;
  let body = '';

  const shapeEl = (kind, x, y, w, h, fill, extra) => {
    if (kind === 'circle' || kind === 'dot') {
      return `<circle cx="${x + w / 2}" cy="${y + h / 2}" r="${w / 2}" fill="${fill}" ${extra || ''}/>`;
    }
    if (kind === 'diamond') {
      return `<polygon points="${x + w / 2},${y} ${x + w},${y + h / 2} ${x + w / 2},${y + h} ${x},${y + h / 2}" fill="${fill}" ${extra || ''}/>`;
    }
    if (kind === 'rounded') {
      return `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${Math.min(w, h) * 0.32}" fill="${fill}" ${extra || ''}/>`;
    }
    return `<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${fill}" ${extra || ''}/>`;
  };

  const fillRef = cfg.useGradient ? 'url(#qrGrad)' : cfg.fg;

  for (let r = 0; r < count; r++) {
    for (let c = 0; c < count; c++) {
      if (!dark(r, c) || inFinderZone(r, c, count)) continue;
      const x = (c + cfg.margin) * cell, y = (r + cfg.margin) * cell;
      const s = cell * cfg.moduleScaleOverride || cell * (STYLES.find(st => st.id === cfg.styleId)?.scale || 0.85);
      const off = (cell - s) / 2;
      body += shapeEl(cfg.moduleShape, x + off, y + off, s, s, fillRef);
    }
  }

  const corners = [
    [cfg.margin, cfg.margin],
    [cfg.margin, cfg.margin + count - 7],
    [cfg.margin + count - 7, cfg.margin],
  ];
  for (const [r0, c0] of corners) {
    const x = c0 * cell, y = r0 * cell, box = cell * 7;
    body += shapeEl(cfg.eyeFrame, x, y, box, box, cfg.eye);
    body += shapeEl(cfg.eyeFrame, x + cell, y + cell, box - cell * 2, box - cell * 2, cfg.bg);
    body += shapeEl(cfg.eyeBall, x + cell * 2, y + cell * 2, box - cell * 4, box - cell * 4, cfg.eye);
  }

  const gradDef = cfg.useGradient
    ? `<defs><linearGradient id="qrGrad" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${cfg.fg}"/><stop offset="1" stop-color="${cfg.gradientEnd}"/></linearGradient></defs>`
    : '';

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">${gradDef}<rect width="${size}" height="${size}" fill="${cfg.bg}"/>${body}</svg>`;

  const blob = new Blob([svg], { type: 'image/svg+xml' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `qr-${state.styleId}.svg`;
  a.click();
  URL.revokeObjectURL(url);
}

/* ---------------- upload flow ---------------- */

const dropzone = document.getElementById('dropzone');
const fileInput = document.getElementById('fileInput');

dropzone.addEventListener('click', () => fileInput.click());
dropzone.addEventListener('dragover', e => { e.preventDefault(); dropzone.classList.add('drag-over'); });
dropzone.addEventListener('dragleave', () => dropzone.classList.remove('drag-over'));
dropzone.addEventListener('drop', e => {
  e.preventDefault();
  dropzone.classList.remove('drag-over');
  if (e.dataTransfer.files[0]) uploadFile(e.dataTransfer.files[0]);
});
fileInput.addEventListener('change', () => {
  if (fileInput.files[0]) uploadFile(fileInput.files[0]);
});

document.getElementById('textSubmit').addEventListener('click', () => {
  const val = document.getElementById('textInput').value.trim();
  if (!val) return;
  enterStudio({ mode: 'text', text: val });
});

document.getElementById('newFileBtn').addEventListener('click', () => {
  document.getElementById('studioSection').classList.add('hidden');
  document.getElementById('uploadSection').classList.remove('hidden');
  fileInput.value = '';
  document.getElementById('textInput').value = '';
});

function uploadFile(file) {
  const progress = document.getElementById('uploadProgress');
  const bar = document.getElementById('progressBar');
  const label = document.getElementById('progressLabel');
  progress.classList.remove('hidden');
  bar.style.width = '0%';
  label.textContent = 'Uploading…';

  const form = new FormData();
  form.append('file', file);

  const xhr = new XMLHttpRequest();
  xhr.open('POST', '/api/upload');
  xhr.upload.onprogress = e => {
    if (e.lengthComputable) bar.style.width = Math.round((e.loaded / e.total) * 100) + '%';
  };
  xhr.onload = () => {
    progress.classList.add('hidden');
    if (xhr.status !== 200) {
      label.textContent = 'Upload failed.';
      alert('Upload failed: ' + xhr.responseText);
      return;
    }
    const data = JSON.parse(xhr.responseText);
    enterStudio({ mode: 'file', data, file });
  };
  xhr.onerror = () => {
    progress.classList.add('hidden');
    alert('Upload failed. Check that the server is running.');
  };
  xhr.send(form);
}

function humanSize(bytes) {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
}

function fileIconSVG() {
  return `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8">
    <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"></path>
    <path d="M14 2v6h6"></path></svg>`;
}

function enterStudio({ mode, data, file, text }) {
  document.getElementById('uploadSection').classList.add('hidden');
  document.getElementById('studioSection').classList.remove('hidden');
  document.getElementById('fileIconWrap').innerHTML = fileIconSVG();

  const preview = document.getElementById('previewBox');
  preview.innerHTML = '';

  if (mode === 'file') {
    qrText = data.url;
    document.getElementById('fileName').textContent = data.filename;
    document.getElementById('fileSub').textContent = `${data.mimeType} · ${humanSize(data.size)}`;
    document.getElementById('directUrl').value = data.url;
    buildFilePreview(preview, data, file);
  } else {
    qrText = text;
    document.getElementById('fileName').textContent = 'Text / URL';
    document.getElementById('fileSub').textContent = `${text.length} characters`;
    document.getElementById('directUrl').value = text;
    const pre = document.createElement('div');
    pre.className = 'generic-preview';
    pre.textContent = text;
    preview.appendChild(pre);
  }

  buildStyleGrid();
  syncControlsFromState();
  redraw();
}

function buildFilePreview(box, data, file) {
  const type = data.mimeType || '';
  const url = data.url;
  if (type.startsWith('image/')) {
    const img = document.createElement('img');
    img.src = url;
    box.appendChild(img);
  } else if (type.startsWith('audio/')) {
    const audio = document.createElement('audio');
    audio.src = url;
    audio.controls = true;
    box.appendChild(audio);
  } else if (type.startsWith('video/')) {
    const video = document.createElement('video');
    video.src = url;
    video.controls = true;
    box.appendChild(video);
  } else if (type === 'application/pdf') {
    const div = document.createElement('div');
    div.className = 'generic-preview';
    div.textContent = 'PDF ready — open the link to view it inline.';
    box.appendChild(div);
  } else if (type === 'text/plain' || type === 'application/json') {
    const pre = document.createElement('pre');
    pre.textContent = 'Loading preview…';
    box.appendChild(pre);
    fetch(url).then(r => r.text()).then(t => { pre.textContent = t.slice(0, 4000); }).catch(() => { pre.textContent = 'Preview unavailable.'; });
  } else {
    const div = document.createElement('div');
    div.className = 'generic-preview';
    div.textContent = `${data.filename}\n${type || 'unknown type'} · ${humanSize(data.size)}`;
    box.appendChild(div);
  }
}

document.getElementById('copyUrlBtn').addEventListener('click', () => {
  const input = document.getElementById('directUrl');
  navigator.clipboard.writeText(input.value).then(() => {
    const btn = document.getElementById('copyUrlBtn');
    const original = btn.innerHTML;
    btn.innerHTML = '<svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 12l5 5L20 6"/></svg>';
    setTimeout(() => { btn.innerHTML = original; }, 1200);
  });
});

/* ---------------- theme ---------------- */

const themeToggle = document.getElementById('themeToggle');
const savedTheme = localStorage.getItem('qr-studio-theme') || 'dark';
document.documentElement.setAttribute('data-theme', savedTheme);

themeToggle.addEventListener('click', () => {
  const next = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', next);
  localStorage.setItem('qr-studio-theme', next);
});

/* ---------------- init ---------------- */

wireControls();
