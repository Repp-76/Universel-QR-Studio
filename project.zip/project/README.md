# Universal QR Studio

Upload any file, get a direct link, turn it into a QR code. One file = one QR code, in 21 distinct visual styles.

## Run

```
npm install
npm start
```

Then open http://localhost:3000

## How it works

- Files are uploaded to `/uploads` and stored under a random ID.
- Each file gets a direct URL: `/f/<id>`. Scanning the QR opens that URL directly — no landing page in between.
- Browsers that can render the file type (images, audio, video, PDF, text) open it inline; everything else downloads.
- QR codes are generated entirely in the browser (matrix from `qrcode-generator`, styling drawn on canvas) so the 21 styles update live as you customize colors, shapes, logo and frame.

Developed by @Repp76
