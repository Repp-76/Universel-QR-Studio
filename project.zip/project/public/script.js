/* ---------------------------------------------------------
   Universal QR Studio — client logic
   QR matrix comes from qrcode-generator (window.qrcode).
   Every style keeps the conventional square-module QR
   structure — only color, contrast, border and framing
   change between styles. Nothing here reshapes the actual
   data modules or finder patterns into decorative shapes.
--------------------------------------------------------- */

const STYLES = [
  { id: 'classic',      name: 'Classic',       fg: '#000000', bg: '#ffffff' },
  { id: 'midnight',     name: 'Midnight',      fg: '#ffffff', bg: '#0b0c10' },
  { id: 'ivory',        name: 'Ivory',         fg: '#1c1c1c', bg: '#f8f5ee' },
  { id: 'slate',        name: 'Slate',         fg: '#1e293b', bg: '#eef1f4' },
  { id: 'carbon',       name: 'Carbon',        fg: '#111111', bg: '#ffffff', border: true },
  { id: 'pearl',        name: 'Pearl',         fg: '#24262b', bg: '#f4f4f2' },
  { id: 'graphite',     name: 'Graphite',      fg: '#2b2b2e', bg: '#ffffff', finderBorder: true },
  { id: 'ocean',        name: 'Ocean',         fg: '#123a5e', bg: '#ffffff' },
  { id: 'emerald',      name: 'Emerald',       fg: '#0b3d2e', bg: '#ffffff' },
  { id: 'royal',        name: 'Royal',         fg: '#1e1b4b', bg: '#ffffff' },
  { id: 'crimson',      name: 'Crimson',       fg: '#5c1a1a', bg: '#ffffff' },
  { id: 'amber',        name: 'Amber',         fg: '#5c3d05', bg: '#fffaf0' },
  { id: 'violet',       name: 'Violet',        fg: '#2e1065', bg: '#ffffff' },
  { id: 'electric',     name: 'Electric',      fg: '#062f4a', bg: '#eaf6ff' },
  { id: 'monochrome',   name: 'Monochrome',    fg: '#000000', bg: '#f2f2f2' },
  { id: 'softcontrast', name: 'Soft Contrast', fg: '#33363b', bg: '#f7f7f5' },
  { id: 'highcontrast', name: 'High Contrast', fg: '#000000', bg: '#ffffff', scale: 1.0, finderBorder: true },
  { id: 'gradient',     name: 'Gradient',      fg: '#1c1c1c', bg: '#ffffff', gradient: ['#1c1c1c', '#4b5563'] },
  { id: 'signature',    name: 'Signature',     fg: '#111111', bg: '#ffffff', border: true, frame: true, frameText: 'SCAN ME' },
  { id: 'premium',      name: 'Premium',       fg: '#141414', bg: '#f7f3ec', border: true, finderBorder: true },
  { id: 'minimal',      name: 'Minimal',       fg: '#000000', bg: '#ffffff' },
];

let state = {
  styleId: 'classic',
  fg: '#000000', bg: '#ffffff', eye: '#000000',
  useGradient: false, gradientEnd: '#4b5563',
  scale: 0.94, finderBorder: false, outerFrame: false,
  margin: 4, ec: 'M',
  logoImg: null, logoSize: 20,
  frameOn: false, frameText: 'SCAN ME',
};

let qrText = null;

/* ---------------- matrix ---------------- */

function buildMatrix(text, ecLevel) {
  const qr = qrcode(0, ecLevel);
  qr.addData(text);
  qr.make();
  const count = qr.getModuleCount();
  return { count, dark: (r, c) => qr.isDark(r, c) };
}

function inFinderZone(row, col, n) {
  return (row < 7 && col < 7) || (row < 7 && col >= n - 7) || (row >= n - 7 && col < 7);
}

/* ---------------- main render ----------------
   Modules and finder patterns are always plain rectangles —
   that's what keeps every style scannable and recognizably
   "QR code" rather than a decorative icon. */

function renderQR(canvas, text, cfg) {
  const style = STYLES.find(s => s.id === cfg.styleId) || STYLES[0];
  const { count, dark } = buildMatrix(text, cfg.ec);
  const n = count + cfg.margin * 2;

  const withFrame = cfg.frameOn || style.frame;
  const qrPx = canvas.__baseSize || canvas.width;
  const framePx = withFrame ? Math.round(qrPx * 0.15) : 0;

  canvas.width = qrPx;
  canvas.height = qrPx + framePx;
  const ctx = canvas.getContext('2d');
  const cell = qrPx / n;

  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = cfg.bg;
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  let fillStyle = cfg.fg;
  if (cfg.useGradient) {
    const grad = ctx.createLinearGradient(0, 0, qrPx, qrPx);
    grad.addColorStop(0, cfg.fg);
    grad.addColorStop(1, cfg.gradientEnd);
    fillStyle = grad;
  }

  // data modules — solid squares, no gaps between them apart from
  // the deliberate module weight the user sets
  ctx.fillStyle = fillStyle;
  for (let r = 0; r < count; r++) {
    for (let c = 0; c < count; c++) {
      if (!dark(r, c) || inFinderZone(r, c, count)) continue;
      const x = (c + cfg.margin) * cell;
      const y = (r + cfg.margin) * cell;
      const s = cell * cfg.scale;
      const off = (cell - s) / 2;
      ctx.fillRect(x + off, y + off, s, s);
    }
  }

  // three finder patterns — traditional square-in-square-in-square
  const corners = [
    [cfg.margin, cfg.margin],
    [cfg.margin, cfg.margin + count - 7],
    [cfg.margin + count - 7, cfg.margin],
  ];
  for (const [r0, c0] of corners) {
    const x = c0 * cell, y = r0 * cell, box = cell * 7;
    ctx.fillStyle = cfg.eye;
    ctx.fillRect(x, y, box, box);
    ctx.fillStyle = cfg.bg;
    ctx.fillRect(x + cell, y + cell, box - cell * 2, box - cell * 2);
    ctx.fillStyle = cfg.eye;
    ctx.fillRect(x + cell * 2, y + cell * 2, box - cell * 4, box - cell * 4);

    if (cfg.finderBorder) {
      ctx.strokeStyle = cfg.eye;
      ctx.lineWidth = Math.max(1, cell * 0.12);
      ctx.strokeRect(x - ctx.lineWidth, y - ctx.lineWidth, box + ctx.lineWidth * 2, box + ctx.lineWidth * 2);
    }
  }

  if (cfg.outerFrame) {
    ctx.strokeStyle = cfg.eye;
    ctx.lineWidth = Math.max(2, qrPx * 0.005);
    const inset = cell * cfg.margin * 0.4;
    ctx.strokeRect(inset, inset, qrPx - inset * 2, qrPx - inset * 2);
  }

  if (cfg.logoImg) {
    const logoBox = qrPx * (cfg.logoSize / 100);
    const cx = qrPx / 2, cy = qrPx / 2;
    const pad = logoBox * 0.2;
    ctx.fillStyle = cfg.bg;
    ctx.fillRect(cx - logoBox / 2 - pad / 2, cy - logoBox / 2 - pad / 2, logoBox + pad, logoBox + pad);
    ctx.drawImage(cfg.logoImg, cx - logoBox / 2, cy - logoBox / 2, logoBox, logoBox);
  }

  if (withFrame) {
    ctx.fillStyle = cfg.eye;
    ctx.fillRect(0, qrPx, qrPx, framePx);
    ctx.fillStyle = cfg.bg;
    ctx.font = `600 ${Math.round(framePx * 0.32)}px Inter, ${getComputedStyle(document.body).fontFamily}`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.letterSpacing = '2px';
    ctx.fillText((cfg.frameText || 'SCAN ME').toUpperCase(), qrPx / 2, qrPx + framePx / 2);
  }
}

function currentConfig() {
  return {
    styleId: state.styleId, fg: state.fg, bg: state.bg, eye: state.eye,
    useGradient: state.useGradient, gradientEnd: state.gradientEnd,
    scale: state.scale, finderBorder: state.finderBorder, outerFrame: state.outerFrame,
    margin: state.margin, ec: state.ec, logoImg: state.logoImg, logoSize: state.logoSize,
    frameOn: state.frameOn, frameText: state.frameText,
  };
}

function redraw() {
  if (!qrText) return;
  const canvas = document.getElementById('qrCanvas');
  canvas.__baseSize = 620;
  renderQR(canvas, qrText, currentConfig());
}

/* ---------------- style grid ---------------- */

function buildStyleGrid() {
  const grid = document.getElementById('styleGrid');
  grid.innerHTML = '';
  STYLES.forEach(style => {
    const cell = document.createElement('div');
    cell.className = 'style-swatch' + (style.id === state.styleId ? ' active' : '');
    cell.dataset.id = style.id;

    const canvas = document.createElement('canvas');
    canvas.__baseSize = 96;
    cell.appendChild(canvas);

    const label = document.createElement('span');
    label.textContent = style.name;
    cell.appendChild(label);

    grid.appendChild(cell);

    const cfg = {
      styleId: style.id,
      fg: style.gradient ? style.gradient[0] : style.fg,
      bg: style.bg, eye: style.fg,
      useGradient: !!style.gradient, gradientEnd: style.gradient ? style.gradient[1] : style.fg,
      scale: style.scale || 0.94, finderBorder: !!style.finderBorder, outerFrame: !!style.border,
      margin: 2, ec: 'M', logoImg: null, logoSize: 20, frameOn: false, frameText: 'SCAN ME',
    };
    renderQR(canvas, 'https://repp76.dev', cfg);

    cell.addEventListener('click', () => applyStyle(style.id));
  });
}

function applyStyle(id) {
  const style = STYLES.find(s => s.id === id);
  if (!style) return;
  state.styleId = id;
  state.fg = style.gradient ? style.gradient[0] : style.fg;
  state.bg = style.bg;
  state.eye = style.fg;
  state.useGradient = !!style.gradient;
  state.gradientEnd = style.gradient ? style.gradient[1] : style.fg;
  state.scale = style.scale || 0.94;
  state.finderBorder = !!style.finderBorder;
  state.outerFrame = !!style.border;
  state.frameOn = !!style.frame;
  if (style.frameText) state.frameText = style.frameText;
  syncControlsFromState();
  document.querySelectorAll('.style-swatch').forEach(el => el.classList.toggle('active', el.dataset.id === id));
  redraw();
}

function syncControlsFromState() {
  document.getElementById('fgColor').value = state.fg;
  document.getElementById('bgColor').value = state.bg;
  document.getElementById('eyeColor').value = state.eye;
  document.getElementById('gradientToggle').checked = state.useGradient;
  document.getElementById('gradientEnd').value = state.gradientEnd;
  document.getElementById('gradientEndRow').classList.toggle('shown', state.useGradient);
  document.getElementById('moduleWeight').value = Math.round(state.scale * 100);
  document.getElementById('finderBorderToggle').checked = state.finderBorder;
  document.getElementById('outerFrameToggle').checked = state.outerFrame;
  document.getElementById('marginRange').value = state.margin;
  document.getElementById('errorCorrection').value = state.ec;
  document.getElementById('frameToggle').checked = state.frameOn;
  document.getElementById('frameTextRow').classList.toggle('shown', state.frameOn);
  document.getElementById('frameText').value = state.frameText;
}

/* ---------------- controls wiring ---------------- */

function wireControls() {
  document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
      tab.classList.add('active');
      document.getElementById('tab-' + tab.dataset.tab).classList.add('active');
    });
  });

  document.getElementById('fgColor').addEventListener('input', e => { state.fg = e.target.value; redraw(); });
  document.getElementById('bgColor').addEventListener('input', e => { state.bg = e.target.value; redraw(); });
  document.getElementById('eyeColor').addEventListener('input', e => { state.eye = e.target.value; redraw(); });
  document.getElementById('gradientToggle').addEventListener('change', e => {
    state.useGradient = e.target.checked;
    document.getElementById('gradientEndRow').classList.toggle('shown', state.useGradient);
    redraw();
  });
  document.getElementById('gradientEnd').addEventListener('input', e => { state.gradientEnd = e.target.value; redraw(); });

  document.getElementById('moduleWeight').addEventListener('input', e => { state.scale = Number(e.target.value) / 100; redraw(); });
  document.getElementById('finderBorderToggle').addEventListener('change', e => { state.finderBorder = e.target.checked; redraw(); });
  document.getElementById('outerFrameToggle').addEventListener('change', e => { state.outerFrame = e.target.checked; redraw(); });
  document.getElementById('marginRange').addEventListener('input', e => { state.margin = Number(e.target.value); redraw(); });
  document.getElementById('errorCorrection').addEventListener('change', e => { state.ec = e.target.value; redraw(); });

  document.getElementById('logoInput').addEventListener('change', e => {
    const file = e.target.files[0];
    if (!file) return;
    const img = new Image();
    img.onload = () => { state.logoImg = img; redraw(); };
    img.src = URL.createObjectURL(file);
  });
  document.getElementById('logoSize').addEventListener('input', e => { state.logoSize = Number(e.target.value); redraw(); });

  document.getElementById('frameToggle').addEventListener('change', e => {
    state.frameOn = e.target.checked;
    document.getElementById('frameTextRow').classList.toggle('shown', state.frameOn);
    redraw();
  });
  document.getElementById('frameText').addEventListener('input', e => { state.frameText = e.target.value; redraw(); });

  document.querySelectorAll('[data-dl]').forEach(btn => {
    btn.addEventListener('click', () => downloadQR(btn.dataset.dl));
  });

  document.querySelectorAll('.seg-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.seg-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const mode = btn.dataset.mode;
      document.getElementById('dropzone').classList.toggle('hidden', mode !== 'file');
      document.getElementById('textFallback').classList.toggle('hidden', mode !== 'text');
    });
  });
}

/* ---------------- export ---------------- */

function downloadQR(format) {
  const canvas = document.getElementById('qrCanvas');
  if (format === 'svg') { downloadSVG(); return; }
  const mimeType = format === 'jpg' ? 'image/jpeg' : 'image/png';
  const url = canvas.toDataURL(mimeType, 0.95);
  const a = document.createElement('a');
  a.href = url;
  a.download = `qr-${state.styleId}.${format}`;
  a.click();
}

function downloadSVG() {
  const cfg = currentConfig();
  const { count, dark } = buildMatrix(qrText, cfg.ec);
  const n = count + cfg.margin * 2;
  const size = 620;
  const cell = size / n;
  let body = '';

  const fillRef = cfg.useGradient ? 'url(#qrGrad)' : cfg.fg;

  for (let r = 0; r < count; r++) {
    for (let c = 0; c < count; c++) {
      if (!dark(r, c) || inFinderZone(r, c, count)) continue;
      const x = (c + cfg.margin) * cell, y = (r + cfg.margin) * cell;
      const s = cell * cfg.scale;
      const off = (cell - s) / 2;
      body += `<rect x="${(x + off).toFixed(2)}" y="${(y + off).toFixed(2)}" width="${s.toFixed(2)}" height="${s.toFixed(2)}" fill="${fillRef}"/>`;
    }
  }

  const corners = [
    [cfg.margin, cfg.margin],
    [cfg.margin, cfg.margin + count - 7],
    [cfg.margin + count - 7, cfg.margin],
  ];
  for (const [r0, c0] of corners) {
    const x = c0 * cell, y = r0 * cell, box = cell * 7;
    body += `<rect x="${x}" y="${y}" width="${box}" height="${box}" fill="${cfg.eye}"/>`;
    body += `<rect x="${x + cell}" y="${y + cell}" width="${box - cell * 2}" height="${box - cell * 2}" fill="${cfg.bg}"/>`;
    body += `<rect x="${x + cell * 2}" y="${y + cell * 2}" width="${box - cell * 4}" height="${box - cell * 4}" fill="${cfg.eye}"/>`;
    if (cfg.finderBorder) {
      body += `<rect x="${x}" y="${y}" width="${box}" height="${box}" fill="none" stroke="${cfg.eye}" stroke-width="${cell * 0.12}"/>`;
    }
  }

  if (cfg.outerFrame) {
    const inset = cell * cfg.margin * 0.4;
    body += `<rect x="${inset}" y="${inset}" width="${size - inset * 2}" height="${size - inset * 2}" fill="none" stroke="${cfg.eye}" stroke-width="${Math.max(2, size * 0.005)}"/>`;
  }

  const gradDef = cfg.useGradient
    ? `<defs><linearGradient id="qrGrad" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${cfg.fg}"/><stop offset="1" stop-color="${cfg.gradientEnd}"/></linearGradient></defs>`
    : '';

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">${gradDef}<rect width="${size}" height="${size}" fill="${cfg.bg}"/>${body}</svg>`;

  const blob = new Blob([svg], { type: 'image/svg+xml' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `qr-${state.styleId}.svg`;
  a.click();
  URL.revokeObjectURL(url);
}

/* ---------------- upload flow ---------------- */

const dropzone = document.getElementById('dropzone');
const fileInput = document.getElementById('fileInput');

dropzone.addEventListener('click', () => fileInput.click());
dropzone.addEventListener('dragover', e => { e.preventDefault(); dropzone.classList.add('drag-over'); });
dropzone.addEventListener('dragleave', () => dropzone.classList.remove('drag-over'));
dropzone.addEventListener('drop', e => {
  e.preventDefault();
  dropzone.classList.remove('drag-over');
  if (e.dataTransfer.files[0]) uploadFile(e.dataTransfer.files[0]);
});
fileInput.addEventListener('change', () => {
  if (fileInput.files[0]) uploadFile(fileInput.files[0]);
});

document.getElementById('textSubmit').addEventListener('click', () => {
  const val = document.getElementById('textInput').value.trim();
  if (!val) return;
  enterStudio({ mode: 'text', text: val });
});

document.getElementById('newFileBtn').addEventListener('click', () => {
  document.getElementById('studioSection').classList.add('hidden');
  document.getElementById('uploadSection').classList.remove('hidden');
  fileInput.value = '';
  document.getElementById('textInput').value = '';
});

function uploadFile(file) {
  const progress = document.getElementById('uploadProgress');
  const bar = document.getElementById('progressBar');
  const label = document.getElementById('progressLabel');
  progress.classList.remove('hidden');
  bar.style.width = '0%';
  label.textContent = 'Uploading…';

  const form = new FormData();
  form.append('file', file);

  const xhr = new XMLHttpRequest();
  xhr.open('POST', '/api/upload');
  xhr.upload.onprogress = e => {
    if (e.lengthComputable) bar.style.width = Math.round((e.loaded / e.total) * 100) + '%';
  };
  xhr.onload = () => {
    progress.classList.add('hidden');
    if (xhr.status !== 200) {
      label.textContent = 'Upload failed.';
      alert('Upload failed: ' + xhr.responseText);
      return;
    }
    const data = JSON.parse(xhr.responseText);
    enterStudio({ mode: 'file', data, file });
  };
  xhr.onerror = () => {
    progress.classList.add('hidden');
    alert('Upload failed. Check that the server is running.');
  };
  xhr.send(form);
}

function humanSize(bytes) {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
}

function fileIconSVG() {
  return `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.7">
    <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"></path>
    <path d="M14 2v6h6"></path></svg>`;
}

function enterStudio({ mode, data, text }) {
  document.getElementById('uploadSection').classList.add('hidden');
  document.getElementById('studioSection').classList.remove('hidden');
  document.getElementById('fileIconWrap').innerHTML = fileIconSVG();

  const preview = document.getElementById('previewBox');
  preview.innerHTML = '';

  if (mode === 'file') {
    qrText = data.url;
    document.getElementById('fileName').textContent = data.filename;
    document.getElementById('fileSub').textContent = `${data.mimeType} · ${humanSize(data.size)}`;
    document.getElementById('directUrl').value = data.url;
    buildFilePreview(preview, data);
  } else {
    qrText = text;
    document.getElementById('fileName').textContent = 'Text / URL';
    document.getElementById('fileSub').textContent = `${text.length} characters`;
    document.getElementById('directUrl').value = text;
    const div = document.createElement('div');
    div.className = 'generic-preview';
    div.textContent = text;
    preview.appendChild(div);
  }

  buildStyleGrid();
  syncControlsFromState();
  redraw();
}

function buildFilePreview(box, data) {
  const type = data.mimeType || '';
  const url = data.url;
  if (type.startsWith('image/')) {
    const img = document.createElement('img');
    img.src = url;
    box.appendChild(img);
  } else if (type.startsWith('audio/')) {
    const audio = document.createElement('audio');
    audio.src = url;
    audio.controls = true;
    box.appendChild(audio);
  } else if (type.startsWith('video/')) {
    const video = document.createElement('video');
    video.src = url;
    video.controls = true;
    box.appendChild(video);
  } else if (type === 'application/pdf') {
    const div = document.createElement('div');
    div.className = 'generic-preview';
    div.textContent = 'PDF ready — open the link to view it inline.';
    box.appendChild(div);
  } else if (type === 'text/plain' || type === 'application/json') {
    const pre = document.createElement('pre');
    pre.textContent = 'Loading preview…';
    box.appendChild(pre);
    fetch(url).then(r => r.text()).then(t => { pre.textContent = t.slice(0, 4000); }).catch(() => { pre.textContent = 'Preview unavailable.'; });
  } else {
    const div = document.createElement('div');
    div.className = 'generic-preview';
    div.textContent = `${data.filename}\n${type || 'unknown type'} · ${humanSize(data.size)}`;
    box.appendChild(div);
  }
}

document.getElementById('copyUrlBtn').addEventListener('click', () => {
  const input = document.getElementById('directUrl');
  navigator.clipboard.writeText(input.value).then(() => {
    const btn = document.getElementById('copyUrlBtn');
    const original = btn.innerHTML;
    btn.innerHTML = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 12l5 5L20 6"/></svg>';
    setTimeout(() => { btn.innerHTML = original; }, 1200);
  });
});

/* ---------------- theme ---------------- */

const themeToggle = document.getElementById('themeToggle');
const savedTheme = localStorage.getItem('qr-studio-theme') || 'dark';
document.documentElement.setAttribute('data-theme', savedTheme);

themeToggle.addEventListener('click', () => {
  const next = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', next);
  localStorage.setItem('qr-studio-theme', next);
});

/* ---------------- init ---------------- */

wireControls();
