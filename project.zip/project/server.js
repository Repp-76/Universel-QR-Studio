const express = require('express');
const multer = require('multer');
const mime = require('mime-types');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const app = express();
const PORT = process.env.PORT || 8980;
const UPLOAD_DIR = path.join(__dirname, 'uploads');
const DB_FILE = path.join(__dirname, 'files.json');
const MAX_SIZE = 200 * 1024 * 1024; // 200MB

if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR);
if (!fs.existsSync(DB_FILE)) fs.writeFileSync(DB_FILE, '{}');

function loadDb() {
  return JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
}
function saveDb(db) {
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
}

// types the browser can open inline instead of downloading
const INLINE_TYPES = [
  'image/', 'audio/', 'video/', 'text/plain', 'application/pdf', 'application/json'
];

function isInline(mimeType) {
  return INLINE_TYPES.some(t => mimeType.startsWith(t));
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => {
    const id = crypto.randomBytes(6).toString('hex');
    const ext = path.extname(file.originalname).toLowerCase().replace(/[^a-z0-9.]/g, '');
    req.fileId = id;
    cb(null, id + ext);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: MAX_SIZE },
  fileFilter: (req, file, cb) => {
    // block only genuinely dangerous executables, everything else is allowed
    const blocked = ['.exe', '.bat', '.cmd', '.sh', '.msi', '.dll'];
    const ext = path.extname(file.originalname).toLowerCase();
    if (blocked.includes(ext)) return cb(new Error('This file type is not allowed.'));
    cb(null, true);
  }
});

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());

app.post('/api/upload', (req, res) => {
  upload.single('file')(req, res, (err) => {
    if (err) return res.status(400).json({ error: err.message });
    if (!req.file) return res.status(400).json({ error: 'No file received.' });

    const id = req.fileId;
    const storedName = req.file.filename;
    const mimeType = mime.lookup(req.file.originalname) || req.file.mimetype || 'application/octet-stream';

    const db = loadDb();
    db[id] = {
      originalName: req.file.originalname,
      storedName,
      mimeType,
      size: req.file.size,
      uploadedAt: Date.now()
    };
    saveDb(db);

    res.json({
      id,
      url: `${req.protocol}://${req.get('host')}/f/${id}`,
      filename: req.file.originalname,
      size: req.file.size,
      mimeType
    });
  });
});

app.get('/f/:id', (req, res) => {
  const id = req.params.id.replace(/[^a-f0-9]/gi, ''); // ids are hex only
  const db = loadDb();
  const entry = db[id];
  if (!entry) return res.status(404).send('File not found.');

  const filePath = path.join(UPLOAD_DIR, entry.storedName);
  if (!filePath.startsWith(UPLOAD_DIR) || !fs.existsSync(filePath)) {
    return res.status(404).send('File not found.');
  }

  res.setHeader('Content-Type', entry.mimeType);
  const disposition = isInline(entry.mimeType) ? 'inline' : 'attachment';
  res.setHeader('Content-Disposition', `${disposition}; filename="${encodeURIComponent(entry.originalName)}"`);
  fs.createReadStream(filePath).pipe(res);
});

app.get('/api/info/:id', (req, res) => {
  const id = req.params.id.replace(/[^a-f0-9]/gi, '');
  const db = loadDb();
  const entry = db[id];
  if (!entry) return res.status(404).json({ error: 'Not found' });
  res.json(entry);
});

app.listen(PORT, () => {
  console.log(`Universal QR Studio running on http://localhost:${PORT}`);
});
